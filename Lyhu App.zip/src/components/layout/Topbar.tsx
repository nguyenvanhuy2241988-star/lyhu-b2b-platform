"use client";

import { Menu, User, MessageCircle } from "lucide-react";
import { NotificationCenter } from "../common/NotificationCenter";
import { useRouter } from "next/navigation";
import { getCurrentUser, logout } from "@/lib/auth";
import { useEffect, useState } from "react";
import { useChatStore } from "@/lib/chatStore";
import { useToast } from "@/components/ui/toast";
import { usePathname } from "next/navigation";

interface TopbarProps {
    onMenuClick: () => void;
    title?: string;
}

export default function Topbar({ onMenuClick, title = "Dashboard" }: TopbarProps) {
    const [userName, setUserName] = useState<string>("User Name");
    const [userId, setUserId] = useState<string | null>(null);
    const router = useRouter();
    const pathname = usePathname();
    const { subscribeToGlobalMessages, unsubscribeFromGlobalMessages } = useChatStore();
    const { showToast } = useToast();

    useEffect(() => {
        (async () => {
            const user = await getCurrentUser();
            if (user) {
                setUserName(user.name || user.email || "User");
                setUserId(user.id);

                // Subscribe to chat notifications
                subscribeToGlobalMessages(user.id, (msg) => {
                    // Don't show toast if we are already on chat page (can refine to check active conversation, but simple for now)
                    if (pathname === '/chat') return;

                    // Check for mention
                    const isMentioned = msg.content.includes(`@${user.email?.split('@')[0]}`) || msg.content.includes(`@${user.name}`); // Rough check

                    showToast(
                        `${isMentioned ? '🔴 Bạn được nhắc đến: ' : 'Tin nhắn mới: '} ${msg.content}`,
                        'info',
                        4000
                    );
                });
            }
        })();

        return () => {
            unsubscribeFromGlobalMessages();
        }
    }, [subscribeToGlobalMessages, unsubscribeFromGlobalMessages, pathname, showToast]);

    const handleLogout = () => {
        logout();
        router.push("/login");
    };

    return (
        <header className="h-16 border-b border-slate-200 bg-white px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30">
            <div className="flex items-center gap-3 sm:gap-4">
                <button
                    onClick={onMenuClick}
                    className="p-2 hover:bg-slate-100 rounded-lg lg:hidden transition-colors"
                    aria-label="Toggle Menu"
                >
                    <Menu className="w-6 h-6 text-slate-600" />
                </button>
                <h2 className="text-base sm:text-lg font-semibold text-slate-900">{title}</h2>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">
                {/* Internal Chat Link */}
                <button
                    onClick={() => router.push('/chat')}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors relative group"
                    title="Tin nhắn nội bộ"
                >
                    <MessageCircle className="w-5 h-5 text-slate-600 group-hover:text-blue-600" />
                    {/* Badge placeholder - logic for unread count would go here */}
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>

                <NotificationCenter />
                <div className="flex items-center gap-2 pl-2 sm:pl-4 border-l border-slate-200">
                    <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center">
                        <User className="w-4 h-4 text-slate-600" />
                    </div>
                    <span className="text-sm font-medium text-slate-700 hidden sm:block">{userName}</span>

                    <button
                        onClick={handleLogout}
                        className="ml-3 text-xs text-slate-500 hover:text-red-500 underline"
                    >
                        Đăng xuất
                    </button>
                </div>
            </div>
        </header>
    );
}
