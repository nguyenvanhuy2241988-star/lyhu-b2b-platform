import { create } from 'zustand';
import { supabase } from './supabaseClient';

// Helper for Pure Fetch
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const getHeaders = (token?: string) => ({
    'Content-Type': 'application/json',
    'apikey': SUPABASE_KEY || '',
    'Authorization': `Bearer ${token || SUPABASE_KEY}`
});

export interface Message {
    id: string;
    conversation_id: string;
    sender_id: string;
    content: string;
    created_at: string;
    is_system: boolean;
    attachment_url?: string;
    attachment_type?: 'image' | 'file';
    attachment_name?: string;
    reply_to_id?: string;
    edited_at?: string;
    is_deleted?: boolean;
    is_pinned?: boolean;
    pinned_at?: string;
    pinned_by?: string;
    reactions?: { emoji: string; user_id: string }[];
    is_forwarded?: boolean;
}

export interface Conversation {
    id: string;
    type: 'direct' | 'group' | 'channel';
    name?: string;
    last_message?: string;
    last_message_at?: string;
    is_public?: boolean;
    participants?: any[];
    internal_participants?: any[]; // Map from DB
    unread_count?: number; // Calculated on client for V1
    is_joined?: boolean;
}

interface ChatState {
    conversations: Conversation[];
    activeConversationId: string | null;
    messages: Message[];
    isLoading: boolean;
    hasMore: boolean;
    isLoadingMore: boolean;
    subscription: any;
    pollingInterval: NodeJS.Timeout | null;

    // Optimized polling state
    lastMessageIdByConversation: Record<string, string>;
    pollingTimers: Record<string, NodeJS.Timeout>;

    // Postgres Changes subscription for messages
    msgChannel: any;
    msgConvId: string | null;

    // Guards to prevent duplicate selectConversation calls
    selectingConvId: string | null;
    selectingReqId: string | null;
    conversationLoadedId: string | null;

    // Loading state flags
    isSelectingConversation: boolean;
    isSendingMessage: boolean;

    fetchConversations: (userId: string, token?: string) => Promise<void>;
    selectConversation: (conversationId: string) => Promise<void>;
    loadMoreMessages: () => Promise<void>;
    sendMessage: (content: string, userId: string, file?: File, replyToId?: string, isSystem?: boolean, isForwarded?: boolean) => Promise<void>;
    editMessage: (messageId: string, newContent: string) => Promise<void>;
    deleteMessage: (messageId: string) => Promise<void>;
    createDirectConversation: (currentUserId: string, targetUserId: string) => Promise<string>;
    createGroupConversation: (currentUserId: string, name: string, participantIds: string[]) => Promise<string>;
    markRead: (conversationId: string, userId: string) => Promise<void>;

    // V6 Group Management
    updateConversationName: (conversationId: string, name: string) => Promise<void>;
    addParticipants: (conversationId: string, userIds: string[]) => Promise<void>;
    leaveConversation: (conversationId: string, userId: string) => Promise<void>;

    subscribeToMessages: (conversationId: string) => void;
    unsubscribeFromMessages: () => void;

    // Postgres Changes message subscription
    subscribeConversationMessages: (conversationId: string) => void;
    unsubscribeConversationMessages: () => void;

    // Optimized polling functions
    startPolling: (conversationId: string) => void;
    stopPolling: (conversationId: string) => void;
    pollConversationOnce: (conversationId: string) => Promise<void>;

    // Presence & Typing (SINGLETON pattern)
    onlineUsers: string[];
    typingUsers: Record<string, string[]>;
    presenceChannel: any;
    presenceUserId: string | null;

    initPresence: (userId: string) => void;
    cleanupPresence: () => void;
    subscribeToPresence: (userId: string) => void;
    unsubscribeFromPresence: () => void;
    sendTyping: (conversationId: string, isTyping: boolean) => void;

    // Read Status
    subscribeToReadStatus: (conversationId: string) => void;
    unsubscribeFromReadStatus: () => void;

    // V4 Features
    pinMessage: (messageId: string) => Promise<void>;
    unpinMessage: (messageId: string) => Promise<void>;
    searchMessages: (query: string, conversationId?: string) => Promise<Message[]>;

    // Global
    globalSubscription: any;
    subscribeToGlobalMessages: (userId: string, onMessage: (msg: any) => void) => void;
    unsubscribeFromGlobalMessages: () => void;

    // V9 Reactions
    addReaction: (messageId: string, emoji: string) => Promise<void>;
    removeReaction: (messageId: string, emoji: string) => Promise<void>;
    subscribeToReactions: (conversationId: string) => void;
    unsubscribeFromReactions: () => void;

    // V9 Forwarding
    forwardMessage: (message: Message, targetConversationIds: string[]) => Promise<void>;
}

// Helper: Compare two arrays of IDs (order-independent)
function sameIds(a: string[], b: string[]): boolean {
    if (a.length !== b.length) return false;
    const setA = new Set(a);
    for (const x of b) {
        if (!setA.has(x)) return false;
    }
    return true;
}

export const useChatStore = create<ChatState>((set, get) => ({
    conversations: [],
    activeConversationId: null,
    messages: [],

    isLoading: false,
    hasMore: false,
    isLoadingMore: false,
    subscription: null,
    pollingInterval: null,

    // Optimized polling state
    lastMessageIdByConversation: {},
    pollingTimers: {},

    // Postgres Changes subscription for messages
    msgChannel: null,
    msgConvId: null,

    // Guards to prevent duplicate selectConversation calls
    selectingConvId: null,
    selectingReqId: null,
    conversationLoadedId: null,

    // Loading state flags
    isSelectingConversation: false,
    isSendingMessage: false,

    // Presence (SINGLETON)
    typingUsers: {},
    presenceChannel: null,
    presenceUserId: null,
    onlineUsers: [],

    fetchConversations: async (userId: string, token?: string) => {
        console.log("Fetching conversations for user:", userId);
        set({ isLoading: true });

        try {
            const headers = getHeaders(token);

            // 1. Fetch participations
            const pRes = await fetch(`${SUPABASE_URL}/rest/v1/internal_participants?user_id=eq.${userId}&select=conversation_id,last_read_at`, { headers });
            const participations = await pRes.json();
            const participationIds = participations?.map((p: any) => p.conversation_id) || [];

            // 2. Fetch PUBLIC channels
            const pubRes = await fetch(`${SUPABASE_URL}/rest/v1/internal_conversations?is_public=eq.true&select=id,name,is_public`, { headers });
            const publicChannels = await pubRes.json();
            const publicIds = publicChannels?.map((c: any) => c.id) || [];

            // Combine IDs
            const allIds = Array.from(new Set([...participationIds, ...publicIds]));

            if (allIds.length === 0) {
                set({ conversations: [], isLoading: false });
                return;
            }

            // 3. Fetch conversations details
            // Supabase PostgREST array filter syntax: id=in.(id1,id2,...)
            // Must handle URL length limits if many IDs, but normally fine.
            const idsFilter = `(${allIds.join(',')})`;
            const cRes = await fetch(`${SUPABASE_URL}/rest/v1/internal_conversations?id=in.${idsFilter}&select=*,internal_participants(user_id)&order=last_message_at.desc`, { headers });
            const conversations = await cRes.json();

            if (cRes.ok && conversations) {
                // Client-side Deduplication (Same logic as before)
                const seenChannels = new Set();
                const seenDMUsers = new Set();

                const uniqueConversations = conversations.filter((c: any) => {
                    if (c.type === 'channel') {
                        if (c.name && seenChannels.has(c.name)) return false;
                        if (c.name) seenChannels.add(c.name);
                        return true;
                    }
                    if (c.type === 'direct' || !c.type) {
                        const other = c.internal_participants?.find((p: any) => p.user_id !== userId);
                        const otherId = other?.user_id;
                        const key = otherId || 'self';
                        if (seenDMUsers.has(key)) return false;
                        seenDMUsers.add(key);
                        return true;
                    }
                    return true;
                });

                const processed = uniqueConversations.map((c: any) => ({
                    ...c,
                    is_joined: participationIds.includes(c.id)
                }));

                set({ conversations: processed, isLoading: false });

                // Fetch unread counts (RPC)
                // Note: RPC via fetch is /rest/v1/rpc/function_name
                const rpcRes = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_unread_counts`, {
                    method: 'POST',
                    headers,
                    body: JSON.stringify({ current_user_id: userId })
                });

                if (rpcRes.ok) {
                    const unreadData = await rpcRes.json();
                    const unreadMap = new Map(unreadData.map((x: any) => [x.conversation_id, x.unread_count]));
                    set(state => ({
                        conversations: state.conversations.map(c => ({
                            ...c,
                            unread_count: Number(unreadMap.get(c.id) || 0)
                        }))
                    }));
                }

            } else {
                console.error("Error fetching conversations:", conversations); // conversations is error body if !ok
                set({ isLoading: false });
            }

        } catch (e) {
            console.error("Exception fetching conversations:", e);
            set({ isLoading: false });
        }
    },

    selectConversation: async (conversationId: string) => {
        const st = get();

        // 1) Already loading this same conversation -> skip (prevents double call)
        if (st.selectingConvId === conversationId) {
            console.log('[SC] already selecting same conv, skipping');
            return;
        }

        // 2) Already loaded and active -> just ensure subscription is alive
        if (st.activeConversationId === conversationId && st.conversationLoadedId === conversationId) {
            console.log('[SC] already loaded, ensuring subscription');
            if (!st.msgChannel || st.msgConvId !== conversationId) {
                get().unsubscribeConversationMessages();
                get().subscribeConversationMessages(conversationId);
            }
            return;
        }

        // Generate unique request ID to detect stale responses
        const reqId = crypto.randomUUID();

        // RESET loading states
        set(state => ({
            selectingConvId: conversationId,
            selectingReqId: reqId,
            activeConversationId: conversationId,
            messages: [],
            hasMore: true,
            isLoadingMore: false,
            isSelectingConversation: true,
            conversations: state.conversations.map(c => c.id === conversationId ? { ...c, unread_count: 0 } : c)
        }));

        const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
        const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

        // Get Token
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token;

        const headers: any = {
            'apikey': SUPABASE_KEY || '',
            'Authorization': `Bearer ${token || SUPABASE_KEY}`
        };

        // Fetch last 50 messages using Direct REST Fetch
        const PAGE_SIZE = 50;
        const fetchUrl = `${SUPABASE_URL}/rest/v1/internal_messages?conversation_id=eq.${conversationId}&select=*,reactions:internal_message_reactions(emoji,user_id)&order=created_at.desc&limit=${PAGE_SIZE}`;
        console.log('[SC] Fetching messages:', conversationId);

        try {
            const res = await fetch(fetchUrl, { headers });

            // Check if this is a stale response (user clicked another conversation)
            if (get().selectingReqId !== reqId) {
                console.log('[SC] stale response, ignoring');
                return;
            }

            if (res.ok) {
                const data = await res.json();
                console.log('[SC] Fetched count:', data?.length || 0);

                // Double check reqId before setting state
                if (get().selectingReqId !== reqId) {
                    console.log('[SC] stale after parse, ignoring');
                    return;
                }

                if (data && data.length > 0) {
                    const reversed = data.reverse();
                    set({
                        messages: reversed,
                        hasMore: data.length === PAGE_SIZE,
                        conversationLoadedId: conversationId
                    });
                } else {
                    set({ messages: [], hasMore: false, conversationLoadedId: conversationId });
                }
            } else {
                const errorText = await res.text();
                console.error('[SC] Error:', res.status, errorText);
            }
        } catch (e) {
            console.error('[SC] Exception:', e);
        }

        // Final check before setting up realtime
        if (get().selectingReqId !== reqId) {
            console.log('[SC] stale before realtime setup, skipping');
            return;
        }

        // Setup Realtime (only if this is still the active request)
        get().unsubscribeFromMessages();          // cleanup broadcast + pollingInterval + reactions/readstatus
        // NOTE: Disabled realtime (postgres_changes) due to CHANNEL_ERROR blocking sends
        // Polling is now the only mechanism for receiving messages
        // get().subscribeConversationMessages(conversationId);
        get().subscribeToReactions(conversationId);
        get().subscribeToReadStatus(conversationId);

        // Clear selecting state
        set({ selectingConvId: null, isSelectingConversation: false });
    },


    loadMoreMessages: async () => {
        const { activeConversationId, messages, isLoadingMore, hasMore, isSelectingConversation } = get();

        // Prevent calling during selectConversation
        if (!activeConversationId || isSelectingConversation) {
            return;
        }

        // Prevent loading more when no messages yet (just selected conversation)
        if (messages.length === 0) {
            return;
        }

        // Prevent duplicate calls
        if (!hasMore || isLoadingMore) {
            return;
        }

        console.log('[ChatStore] loadMoreMessages START');
        set({ isLoadingMore: true });

        const PAGE_SIZE = 50;
        const currentCount = messages.length;

        const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
        const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token;

        const headers: any = {
            'apikey': SUPABASE_KEY || '',
            'Authorization': `Bearer ${token || SUPABASE_KEY}`,
            'Range': `${currentCount}-${currentCount + PAGE_SIZE - 1}`
        };

        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/internal_messages?conversation_id=eq.${activeConversationId}&select=*,reactions:internal_message_reactions(emoji,user_id)&order=created_at.desc`, {
                headers
            });

            if (res.ok) {
                const data = await res.json();
                console.log(`[ChatStore] loadMoreMessages Success. Got ${data.length} messages.`);

                if (data.length > 0) {
                    const reversed = data.reverse();
                    set((state) => ({
                        messages: [...reversed, ...state.messages],
                        hasMore: data.length === PAGE_SIZE,
                        isLoadingMore: false
                    }));
                } else {
                    set({ hasMore: false, isLoadingMore: false });
                }
            } else {
                console.error('[ChatStore] loadMoreMessages API Error:', await res.text());
                set({ isLoadingMore: false });
            }
        } catch (e) {
            console.error('[ChatStore] loadMoreMessages Exception:', e);
            set({ isLoadingMore: false });
        }
    },

    // --- V6 Group Management ---

    updateConversationName: async (conversationId: string, name: string) => {
        const { error } = await supabase
            .from('internal_conversations')
            .update({ name })
            .eq('id', conversationId);

        if (error) throw error;

        // Optimistic update
        set(state => ({
            conversations: state.conversations.map(c =>
                c.id === conversationId ? { ...c, name } : c
            )
        }));

        // System Message
        const user = (await supabase.auth.getUser()).data.user;
        if (user) {
            await get().sendMessage(`đã đổi tên nhóm thành "${name}"`, user.id, undefined, undefined, true);
        }
    },

    addParticipants: async (conversationId: string, userIds: string[]) => {
        const toInsert = userIds.map(uid => ({
            conversation_id: conversationId,
            user_id: uid
        }));

        const { error } = await supabase
            .from('internal_participants')
            .insert(toInsert);

        if (error) throw error;

        // Only refresh conversation list metadata (do NOT call selectConversation - it resets realtime)
        const user = (await supabase.auth.getUser()).data.user;
        if (user) {
            await get().fetchConversations(user.id);
            // System message - receiver will get it via postgres_changes
            await get().sendMessage(`đã thêm ${userIds.length} thành viên mới`, user.id, undefined, undefined, true);
        }
    },

    leaveConversation: async (conversationId: string, userId: string) => {
        // System Message BEFORE leaving (so they are still author)
        // Actually, RLS might prevent insert if not participant? 
        // Security Definer usually handles triggers, but manual insert depends on Policy.
        // Policy usually: "Participant can insert". If I delete first, I can't insert?
        // Let's insert first.
        try {
            await get().sendMessage(`đã rời nhóm`, userId, undefined, undefined, true);
        } catch (e) {
            console.error("Failed to send leave message", e);
        }

        const { error } = await supabase
            .from('internal_participants')
            .delete()
            .eq('conversation_id', conversationId)
            .eq('user_id', userId);

        if (error) throw error;

        // Remove locally
        set(state => ({
            conversations: state.conversations.filter(c => c.id !== conversationId),
            activeConversationId: state.activeConversationId === conversationId ? null : state.activeConversationId,
            messages: state.activeConversationId === conversationId ? [] : state.messages
        }));
    },

    sendMessage: async (content: string, userId: string, file?: File, replyToId?: string, isSystem: boolean = false, isForwarded: boolean = false) => {
        const { activeConversationId, conversations, fetchConversations, messages } = get();
        if (!activeConversationId) return;

        // Set sending flag
        set({ isSendingMessage: true });

        try {
            // Check if joined, if not, try to join (insert participant) first
            const currentConv = conversations.find(c => c.id === activeConversationId);
            if (currentConv && currentConv.is_public && !currentConv.is_joined) {
                // Auto-join logic
                const { error: joinError } = await supabase
                    .from('internal_participants')
                    .insert({ conversation_id: activeConversationId, user_id: userId });

                if (joinError) console.error("Error joining channel:", joinError);
                else {
                    // Refresh joined state
                    await fetchConversations(userId);
                }
            }

            let attachmentUrl = null;
            let attachmentType = null;
            let attachmentName = null;

            // Upload file if exists
            if (file) {
                const fileExt = file.name.split('.').pop();
                const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
                const filePath = `${activeConversationId}/${fileName}`;

                const { error: uploadError } = await supabase.storage
                    .from('chat-attachments')
                    .upload(filePath, file);

                if (uploadError) {
                    console.error("Error uploading file:", uploadError);
                    return; // Stop if upload fails
                }

                const { data: { publicUrl } } = supabase.storage
                    .from('chat-attachments')
                    .getPublicUrl(filePath);

                attachmentUrl = publicUrl;
                attachmentType = file.type.startsWith('image/') ? 'image' : 'file';
                attachmentName = file.name;
            }

            // OPTIMISTIC UPDATE: Add message to UI immediately with CLIENT-SIDE UUID
            // This allows us to deduplicate in the realtime subscription
            const messageId = crypto.randomUUID();

            const optimisticMessage: Message = {
                id: messageId,
                conversation_id: activeConversationId,
                sender_id: userId,
                content: content || (file ? "Đã gửi một tệp" : ""),
                created_at: new Date().toISOString(),
                is_system: isSystem,
                is_forwarded: isForwarded,
                attachment_url: attachmentUrl || (file ? URL.createObjectURL(file) : undefined),
                attachment_type: attachmentType as any || (file ? (file.type.startsWith('image/') ? 'image' : 'file') : undefined),
                attachment_name: attachmentName || file?.name,
                reply_to_id: isSystem ? undefined : replyToId
            };

            // Add to messages array immediately
            set({ messages: [...messages, optimisticMessage] });

            const { data, error } = await supabase
                .from('internal_messages')
                .insert({
                    id: messageId, // Explicitly set ID
                    conversation_id: activeConversationId,
                    sender_id: userId,
                    content: content || (file ? "Đã gửi một tệp" : ""),
                    attachment_url: attachmentUrl,
                    attachment_type: attachmentType,
                    attachment_name: attachmentName,
                    is_system: isSystem,
                    is_forwarded: isForwarded,
                    reply_to_id: isSystem ? null : replyToId
                })
                .select()
                .single();

            console.log('[ChatStore] Send Message Result:', { data, error });

            if (error) {
                console.error('Error sending message:', error);
                // Remove optimistic message on error
                set({ messages: messages.filter(m => m.id !== messageId) });
            } else if (data) {
                console.log('[ChatStore] Send Success. DB Data:', data);
                // Update with server data (e.g. for exact created_at)
                set({
                    messages: get().messages.map(m =>
                        m.id === messageId ? data : m
                    )
                });

                // NOTE: Broadcast removed - using postgres_changes for realtime now
                // Receiver will get the message via subscribeConversationMessages()
            }

            // Update conversation last_message
            await supabase
                .from('internal_conversations')
                .update({
                    last_message: content || (attachmentType === 'image' ? '[Hình ảnh]' : '[Tập tin]'),
                    last_message_at: new Date().toISOString()
                })
                .eq('id', activeConversationId);

        } finally {
            // ALWAYS clear sending flag, even on errors
            set({ isSendingMessage: false });
        }
    },

    editMessage: async (messageId: string, newContent: string) => {
        // Optimistic update
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId
                    ? { ...m, content: newContent, edited_at: new Date().toISOString() }
                    : m
            )
        }));

        const { error } = await supabase
            .from('internal_messages')
            .update({ content: newContent, edited_at: new Date().toISOString() })
            .eq('id', messageId);

        if (error) {
            console.error("Error editing message:", error);
            // Revert could be implemented here if needed, but for now we rely on realtime or refresh
        }
    },

    deleteMessage: async (messageId: string) => {
        // Optimistic update
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId
                    ? { ...m, is_deleted: true, content: "Tin nhắn đã bị thu hồi", attachment_url: undefined }
                    : m
            )
        }));

        const { error } = await supabase
            .from('internal_messages')
            .update({ is_deleted: true, content: "Tin nhắn đã bị thu hồi", attachment_url: null }) // DB allows null, interface uses undefined
            .eq('id', messageId);

        if (error) {
            console.error("Error deleting message:", error);
        }
    },

    createGroupConversation: async (currentUserId: string, name: string, participantIds: string[]) => {
        // Create conversation
        const { data: conv, error: createError } = await supabase
            .from('internal_conversations')
            .insert({
                type: 'group',
                name: name,
                last_message_at: new Date().toISOString(),
                is_public: false
            })
            .select()
            .single();

        if (createError || !conv) {
            console.error('Error creating group:', createError);
            throw createError || new Error('Failed to create group');
        }

        // Prepare participants (currentUser + selected users)
        const allUserIds = Array.from(new Set([currentUserId, ...participantIds]));
        const participantsData = allUserIds.map(uid => ({
            conversation_id: conv.id,
            user_id: uid
        }));

        const { error: participantsError } = await supabase
            .from('internal_participants')
            .insert(participantsData);

        if (participantsError) {
            console.error('Error adding group participants:', participantsError);
        }

        // Refresh
        await get().fetchConversations(currentUserId);
        return conv.id;
    },

    createDirectConversation: async (currentUserId: string, targetUserId: string) => {
        // CRITICAL FIX: Order by last_message_at DESC to match fetchConversations deduplication
        // This ensures we always select the SAME conversation that's visible in the sidebar
        const { data: allDirectConvs, error: fetchError } = await supabase
            .from('internal_conversations')
            .select(`
                id,
                type,
                last_message_at,
                internal_participants!inner(user_id)
            `)
            .eq('type', 'direct')
            .order('last_message_at', { ascending: false, nullsFirst: false });

        if (fetchError) {
            console.error('Error fetching conversations:', fetchError);
        }

        // Find ALL existing conversations where both users are participants
        const matchingConvs = allDirectConvs?.filter((conv: any) => {
            const participants = conv.internal_participants;
            if (!participants || participants.length !== 2) return false;

            const userIds = participants.map((p: any) => p.user_id);
            return userIds.includes(currentUserId) && userIds.includes(targetUserId);
        }) || [];

        console.log(`Found ${matchingConvs.length} matching DM conversations`);

        if (matchingConvs.length > 0) {
            // Return the FIRST one (which is the most recent due to ordering)
            // This matches fetchConversations deduplication behavior
            const mostRecent = matchingConvs[0];
            console.log('Selecting most recent DM:', mostRecent.id);

            // If there are duplicates, log a warning but don't delete here
            // (deletion should be done via SQL migration)
            if (matchingConvs.length > 1) {
                console.warn(`Found ${matchingConvs.length} duplicate DMs between users. Consider running cleanup migration.`);
            }

            return mostRecent.id;
        }

        // No existing conversation - create new one
        console.log('No existing DM found, creating new conversation');
        const { data: conv, error: createError } = await supabase
            .from('internal_conversations')
            .insert({ type: 'direct', last_message_at: new Date().toISOString() })
            .select()
            .single();

        if (createError || !conv) {
            console.error('Error creating conversation:', createError);
            throw createError || new Error('Failed to create conversation');
        }

        // Insert participants
        const { error: participantsError } = await supabase
            .from('internal_participants')
            .insert([
                { conversation_id: conv.id, user_id: currentUserId },
                { conversation_id: conv.id, user_id: targetUserId }
            ]);

        if (participantsError) {
            console.error('Error adding participants:', participantsError);
        }

        // Refresh conversation list
        await get().fetchConversations(currentUserId);
        return conv.id;
    },

    markRead: async (conversationId: string, userId: string) => {
        await supabase
            .from('internal_participants')
            .update({ last_read_at: new Date().toISOString() })
            .eq('conversation_id', conversationId)
            .eq('user_id', userId);
    },

    subscribeToMessages: async (conversationId: string) => {
        const state = get();

        // Prevent re-subscribing to the same conversation
        if (state.activeConversationId === conversationId && state.subscription) {
            return;
        }

        // Unsubscribe existing if any
        if (state.subscription) {
            get().unsubscribeFromMessages();
        }

        const { data: { session } } = await supabase.auth.getSession();

        // Use a SHARED channel name for the conversation
        const channelName = `chat-broadcast:${conversationId}`;

        const channel = supabase
            .channel(channelName)
            .on('broadcast', { event: 'new_message' }, (payload: { payload: Message }) => {
                try {
                    const msg = payload.payload;
                    if (!msg || !msg.id) return;

                    // Skip own messages (already added optimistically)
                    const currentUserId = session?.user?.id;
                    if (msg.sender_id === currentUserId) return;

                    // Only process messages for the active conversation
                    const currentState = get();
                    if (msg.conversation_id !== currentState.activeConversationId) return;

                    set((s) => {
                        // Prevent duplicates
                        if (s.messages.some(m => m.id === msg.id)) return s;

                        return {
                            messages: [...s.messages, msg],
                            lastMessageIdByConversation: {
                                ...s.lastMessageIdByConversation,
                                [msg.conversation_id]: msg.id
                            }
                        };
                    });
                } catch (e) {
                    console.error('[ChatStore] Broadcast error:', e);
                }
            })
            .subscribe();

        // Store the channel reference (polling is handled separately by startPolling/stopPolling)
        set({ subscription: channel });
    },

    unsubscribeFromMessages: () => {
        const { subscription, pollingInterval } = get();
        if (subscription) {
            supabase.removeChannel(subscription);
            set({ subscription: null });
        }
        if (pollingInterval) {
            clearInterval(pollingInterval);
            set({ pollingInterval: null });
        }
        // NOTE: Do NOT call unsubscribeConversationMessages here!
        // msgChannel is managed by subscribeConversationMessages only when switching conversations
        get().unsubscribeFromReactions();
        get().unsubscribeFromReadStatus();
    },

    // ============ POSTGRES CHANGES MESSAGE SUBSCRIPTION ============

    subscribeConversationMessages: (conversationId: string) => {
        const { msgChannel, msgConvId } = get();
        if (!conversationId) return;

        console.log('[RT] subscribeConversationMessages ->', conversationId);

        // Already subscribed to this conversation - NEVER remove
        if (msgChannel && msgConvId === conversationId) {
            console.log('[RT] already subscribed same conv, skip');
            return;
        }

        // ONLY remove old channel when switching to a DIFFERENT conversation
        if (msgChannel && msgConvId !== conversationId) {
            console.log('[RT] switch conv:', msgConvId, '->', conversationId);
            supabase.removeChannel(msgChannel);
        }

        const SCHEMA = 'public'; // Change if your table is in a different schema

        const ch = supabase
            .channel(`chat-db:${conversationId}`)
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: SCHEMA,
                    table: 'internal_messages',
                    filter: `conversation_id=eq.${conversationId}`
                },
                (payload: { new: Message }) => {
                    const msg = payload.new;
                    console.log('[RT] INSERT received:', msg?.id);

                    const st = get();
                    if (st.activeConversationId !== conversationId) {
                        console.log('[RT] ignoring - different active conv');
                        return;
                    }

                    set((state) => {
                        // Prevent duplicates
                        if (state.messages.some(m => m.id === msg.id)) {
                            console.log('[RT] duplicate, skipping');
                            return state;
                        }

                        console.log('[RT] appending message to UI');
                        return {
                            messages: [...state.messages, msg],
                            lastMessageIdByConversation: {
                                ...state.lastMessageIdByConversation,
                                [conversationId]: msg.id
                            }
                        };
                    });
                }
            )
            .subscribe((status: string) => {
                console.log('[RT] msgChannel status:', status);
            });

        set({ msgChannel: ch, msgConvId: conversationId });
    },

    unsubscribeConversationMessages: () => {
        const { msgChannel } = get();
        if (msgChannel) {
            console.log('[RT] remove msgChannel');
            supabase.removeChannel(msgChannel);
        }
        set({ msgChannel: null, msgConvId: null });
    },

    // ============ SIMPLE RELIABLE POLLING (NO OPTIMIZATION) ============

    pollConversationOnce: async (conversationId: string) => {
        try {
            const st = get();
            // Skip if not active conversation
            if (st.activeConversationId !== conversationId) return;

            // ALWAYS fetch latest 50 messages
            const { data: list, error } = await supabase
                .from('internal_messages')
                .select('*,reactions:internal_message_reactions(emoji,user_id)')
                .eq('conversation_id', conversationId)
                .order('created_at', { ascending: true })
                .limit(50);

            if (error) {
                console.error('[Poll] error:', error);
                return;
            }

            // Merge: only update if there are NEW messages (by comparing last id)
            set((state) => {
                if (state.activeConversationId !== conversationId) return state;

                const currentLastId = state.messages[state.messages.length - 1]?.id;
                const newLastId = list?.[list.length - 1]?.id;

                // If same last message, no update needed
                if (currentLastId === newLastId && state.messages.length === list?.length) {
                    return state;
                }

                // New messages! Update state
                console.log('[Poll] New messages detected, updating UI');
                return {
                    messages: list ?? []
                };
            });
        } catch (e) {
            console.error('[Poll] exception:', e);
        }
    },

    startPolling: (conversationId: string) => {
        const { pollingTimers } = get();

        // Already polling this conversation
        if (pollingTimers[conversationId]) {
            return;
        }

        console.log('[Poll] Starting polling every 2s for:', conversationId);

        // Poll immediately once
        get().pollConversationOnce(conversationId);

        // Then poll every 2 seconds
        const timerId = setInterval(() => {
            get().pollConversationOnce(conversationId);
        }, 2000);

        set((state) => ({
            pollingTimers: {
                ...state.pollingTimers,
                [conversationId]: timerId
            }
        }));
    },

    stopPolling: (conversationId: string) => {
        const { pollingTimers } = get();
        const timer = pollingTimers[conversationId];

        if (timer) {
            clearInterval(timer);
            set((state) => {
                const newTimers = { ...state.pollingTimers };
                delete newTimers[conversationId];
                return { pollingTimers: newTimers };
            });
        }
    },

    subscribeToReadStatus: (conversationId: string) => {
        supabase
            .channel(`read:${conversationId}`)
            .on(
                'postgres_changes',
                { event: 'UPDATE', schema: 'public', table: 'internal_participants', filter: `conversation_id=eq.${conversationId}` },
                (payload: any) => {
                    // Update the conversation's participant last_read_at
                    const { conversations } = get();
                    const updatedConvs = conversations.map(c => {
                        if (c.id === conversationId && c.internal_participants) {
                            return {
                                ...c,
                                internal_participants: c.internal_participants.map((p: any) =>
                                    p.user_id === payload.new.user_id ? { ...p, last_read_at: payload.new.last_read_at } : p
                                )
                            };
                        }
                        return c;
                    });
                    set({ conversations: updatedConvs });
                }
            )
            .subscribe();
    },

    unsubscribeFromReadStatus: () => {
        const { activeConversationId } = get();
        if (activeConversationId) {
            supabase.removeChannel(supabase.channel(`read:${activeConversationId}`));
        }
    },

    // Global Notifications
    globalSubscription: null as any,
    subscribeToGlobalMessages: (userId: string, onMessage: (msg: any) => void) => {
        const { globalSubscription } = get();
        if (globalSubscription) return; // Already subscribed

        // We listen to ALL messages. RLS ensures we only get ours.
        const channel = supabase
            .channel(`global-messages:${userId}`)
            .on(
                'postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'internal_messages' },
                (payload: any) => {
                    const msg = payload.new;
                    // Ignore own messages
                    if (msg.sender_id === userId) return;

                    // Update Unread Count if not active
                    const { activeConversationId, conversations } = get();
                    if (msg.conversation_id !== activeConversationId) {
                        set({
                            conversations: conversations.map(c =>
                                c.id === msg.conversation_id
                                    ? { ...c, unread_count: (c.unread_count || 0) + 1, last_message: msg.content, last_message_at: msg.created_at }
                                    : c
                            )
                        });
                        // Callback for Toast
                        onMessage(msg);
                    } else {
                        // If active, just update last message preview (optional, real-time message list handles headers?)
                        // Conversation list needs update too
                        set({
                            conversations: conversations.map(c =>
                                c.id === msg.conversation_id
                                    ? { ...c, last_message: msg.content, last_message_at: msg.created_at }
                                    : c
                            )
                        });
                    }
                }
            )
            .subscribe();

        set({ globalSubscription: channel });
    },
    unsubscribeFromGlobalMessages: () => {
        const { globalSubscription } = get();
        if (globalSubscription) {
            globalSubscription.unsubscribe();
            set({ globalSubscription: null });
        }
    },

    // --- Presence (Online Status & Typing) - SINGLETON PATTERN ---

    initPresence: (userId: string) => {
        const state = get();
        if (!userId) return;

        // Already initialized for this user - skip
        if (state.presenceChannel && state.presenceUserId === userId) {
            return;
        }

        // Cleanup old channel if exists
        if (state.presenceChannel) {
            supabase.removeChannel(state.presenceChannel);
        }

        const channel = supabase.channel('presence:internal', {
            config: { presence: { key: userId } }
        });

        channel
            .on('presence', { event: 'sync' }, () => {
                const ps = channel.presenceState();

                // Extract unique user IDs
                const nextIds: string[] = [];
                Object.values(ps).forEach((presences: any) => {
                    presences.forEach((p: any) => {
                        if (p.user_id && !nextIds.includes(p.user_id)) {
                            nextIds.push(p.user_id);
                        }
                    });
                });

                // ONLY set state if IDs actually changed
                const prevIds = get().onlineUsers;
                if (!sameIds(prevIds, nextIds)) {
                    set({ onlineUsers: nextIds });
                }

                // Parse typing state
                const typingMap: Record<string, string[]> = {};
                Object.values(ps).forEach((presences: any) => {
                    presences.forEach((p: any) => {
                        if (p.typing && p.conversation_id && p.user_id) {
                            if (!typingMap[p.conversation_id]) typingMap[p.conversation_id] = [];
                            if (!typingMap[p.conversation_id].includes(p.user_id)) {
                                typingMap[p.conversation_id].push(p.user_id);
                            }
                        }
                    });
                });
                set({ typingUsers: typingMap });
            })
            .on('presence', { event: 'join' }, () => {
                // Join triggers sync, no need to update state here
            })
            .on('presence', { event: 'leave' }, () => {
                // Leave triggers sync, no need to update state here
            })
            .subscribe(async (status: string) => {
                if (status === 'SUBSCRIBED') {
                    await channel.track({
                        online_at: new Date().toISOString(),
                        user_id: userId,
                        typing: false
                    });
                }
            });

        set({ presenceChannel: channel, presenceUserId: userId });
    },

    cleanupPresence: () => {
        const ch = get().presenceChannel;
        if (ch) {
            supabase.removeChannel(ch);
        }
        set({ presenceChannel: null, presenceUserId: null, onlineUsers: [] });
    },

    // Keep for backwards compatibility
    subscribeToPresence: (userId: string) => {
        get().initPresence(userId);
    },

    unsubscribeFromPresence: () => {
        get().cleanupPresence();
    },

    sendTyping: async (conversationId: string, isTyping: boolean) => {
        const { presenceChannel, presenceUserId } = get();
        if (!presenceChannel || !presenceUserId) return;

        await presenceChannel.track({
            online_at: new Date().toISOString(),
            user_id: presenceUserId,
            conversation_id: conversationId,
            typing: isTyping
        });
    },

    // --- V9 Reactions ---
    addReaction: async (messageId: string, emoji: string) => {
        const userId = (await supabase.auth.getUser()).data.user?.id;
        if (!userId) return;

        // Optimistic Update
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId
                    ? { ...m, reactions: [...(m.reactions || []), { emoji, user_id: userId }] }
                    : m
            )
        }));

        await supabase
            .from('internal_message_reactions')
            .insert({ message_id: messageId, emoji, user_id: userId });
    },

    removeReaction: async (messageId: string, emoji: string) => {
        const userId = (await supabase.auth.getUser()).data.user?.id;
        if (!userId) return;

        // Optimistic Update
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId
                    ? { ...m, reactions: (m.reactions || []).filter(r => !(r.emoji === emoji && r.user_id === userId)) }
                    : m
            )
        }));

        await supabase
            .from('internal_message_reactions')
            .delete()
            .eq('message_id', messageId)
            .eq('emoji', emoji)
            .eq('user_id', userId);
    },

    subscribeToReactions: (conversationId: string) => {
        const channel = supabase
            .channel(`reactions:${conversationId}`)
            .on(
                'postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'internal_message_reactions' },
                (payload) => {
                    const newReaction = payload.new;
                    set(state => ({
                        messages: state.messages.map(m => {
                            if (m.id !== newReaction.message_id) return m;
                            // Dedup: Check if this user already reacted with this emoji
                            const exists = (m.reactions || []).some(r => r.user_id === newReaction.user_id && r.emoji === newReaction.emoji);
                            if (exists) return m;
                            return { ...m, reactions: [...(m.reactions || []), { emoji: newReaction.emoji, user_id: newReaction.user_id }] };
                        })
                    }));
                }
            )
            .on(
                'postgres_changes',
                { event: 'DELETE', schema: 'public', table: 'internal_message_reactions' },
                (payload) => {
                    const oldReaction = payload.old; // Only has ID usually? No, full row if REPLICA IDENTITY FULL, otherwise need ID. 
                    // Supabase DELETE payload usually only has Primary Key. `id`.
                    // We need message_id to find the message.
                    // If we can't get message_id, we might have to reload?
                    // Actually, for delete, Supabase passes `id` (PK) in `old`.
                    // But our state structure is nested. We don't have a map of reaction_id -> message_id.
                    // Ideally we should store reaction `id` in the state too.
                    // Current Message interface: reactions?: { emoji: string; user_id: string }[];
                    // It doesn't store reaction ID.
                    // This is a problem for precise deletion by ID.
                    // However, we can match by (user_id, emoji).
                    // Does DELETE payload contain non-PK columns? NOT by default.
                    // Workaround: We might need to fetch the message again or rely on the optimistic update being correct.
                    // BUT, if another user deletes their reaction, we receive a DELETE event. We need to know WHICH reaction.
                    // If we don't have message_id in payload, we are stuck.
                    // Solution: We probably can't easily fix "realtime delete reflection" without Schema change (Replica Identity) or fetching.
                    // Let's at least fix the ADD duplication.
                    // For the user's report "Thả 1 icon nhưng nó nhân thành 2", that's the INSERT duplication.
                }
            )
            .subscribe();
    },

    unsubscribeFromReactions: () => {
        const { activeConversationId } = get();
        if (activeConversationId) {
            supabase.removeChannel(supabase.channel(`reactions:${activeConversationId}`));
        }
    },

    pinMessage: async (messageId: string) => {
        const user = (await supabase.auth.getUser()).data.user;
        if (!user) return;

        // Optimistic
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId ? { ...m, is_pinned: true, pinned_at: new Date().toISOString(), pinned_by: user.id } : m
            )
        }));

        await supabase
            .from('internal_messages')
            .update({ is_pinned: true, pinned_at: new Date().toISOString(), pinned_by: user.id })
            .eq('id', messageId);
    },

    unpinMessage: async (messageId: string) => {
        // Optimistic
        set(state => ({
            messages: state.messages.map(m =>
                m.id === messageId ? { ...m, is_pinned: false, pinned_at: undefined, pinned_by: undefined } : m
            )
        }));

        await supabase
            .from('internal_messages')
            .update({ is_pinned: false, pinned_at: null, pinned_by: null })
            .eq('id', messageId);
    },

    // V10: Media Gallery
    getChatMedia: async (conversationId: string) => {
        const { data, error } = await supabase
            .from('internal_messages')
            .select('id, attachment_url, attachment_type, attachment_name, created_at, content')
            .eq('conversation_id', conversationId)
            .not('attachment_url', 'is', null) // Filter where attachment_url is not null
            .is('is_deleted', false)
            .order('created_at', { ascending: false });

        if (error) {
            console.error("Error fetching media:", error);
            return [];
        }
        return data || [];
    },

    searchMessages: async (query: string, conversationId?: string) => {
        let builder = supabase
            .from('internal_messages')
            .select('*')
            .ilike('content', `%${query}%`)
            .eq('is_deleted', false)
            .order('created_at', { ascending: false })
            .limit(20);

        if (conversationId) {
            builder = builder.eq('conversation_id', conversationId);
        } else {
            // If global search, we should probably only search conversations user is in.
            // But for now, let's keep it simple: Search within active conversation is the main use case.
            // If no conversationId, we might not allow global search yet or rely on RLS.
        }

        const { data, error } = await builder;
        if (error) {
            console.error("Error searching messages:", error);
            return [];
        }
        return data || [];
    },

    forwardMessage: async (message: Message, targetConversationIds: string[]) => {
        const userId = (await supabase.auth.getUser()).data.user?.id;
        if (!userId) return;

        const content = message.content;
        const attachmentUrl = message.attachment_url;
        const attachmentType = message.attachment_type;
        const attachmentName = message.attachment_name;

        for (const targetId of targetConversationIds) {
            await supabase.from('internal_messages').insert({
                conversation_id: targetId,
                sender_id: userId,
                content: content,
                attachment_url: attachmentUrl,
                attachment_type: attachmentType,
                attachment_name: attachmentName,
                is_forwarded: true
            });

            await supabase
                .from('internal_conversations')
                .update({
                    last_message: content || (attachmentType === 'image' ? '[Hình ảnh]' : '[Tập tin]'),
                    last_message_at: new Date().toISOString()
                })
                .eq('id', targetId);
        }
    }
}));
