import type { TelesalesTask } from "./telesalesTasksStore";

export function asArray<T>(v: any): T[] {
    return Array.isArray(v) ? v : [];
}

export function calculateKpiProgress(tasksLike: any) {
    const tasks = asArray<TelesalesTask>(tasksLike);
    const total = tasks.length;
    const done = tasks.filter(t => t.status === "done").length;
    const progress = total === 0 ? 0 : Math.round((done / total) * 100);

    // Also return status and percentage for earnings page compatibility
    let status: 'good' | 'warning' | 'bad' = 'bad';
    if (progress >= 80) status = 'good';
    else if (progress >= 50) status = 'warning';

    return { total, done, progress, status, percentage: progress };
}

export function filterTasksByCompletionDate(tasksLike: any, from: Date, to: Date) {
    const tasks = asArray<TelesalesTask>(tasksLike);
    const fromTime = from.getTime();
    const toTime = to.getTime();
    return tasks.filter(t => {
        if (!t.completed_at) return false;
        const time = new Date(t.completed_at).getTime();
        return time >= fromTime && time <= toTime;
    });
}

// Fix build error: calculateKpiMetrics was missing
export function calculateKpiMetrics(...args: any[]) {
    return {
        totalTasks: 0,
        doneTasks: 0,
        totalLeads: 0,
        doneLeads: 0,
        conversion: 0,
    };
}

// Fix build error: Missing exports for admin telesales earnings page
export type AdminTeleKpiRow = {
    userId: string;
    userName: string;
    totalCalls: number;
    totalOrders: number;
    totalRevenue: number;
    totalCommission: number;
    conversionRate: number;
    overallProgress: number;
};

export async function getGlobalKpiSummary(from: Date, to: Date) {
    return {
        totalCalls: 0,
        totalOrders: 0,
        totalRevenue: 0,
        totalCommission: 0,
        conversionRate: 0
    };
}

export async function getKpiSummaryByUser(from: Date, to: Date): Promise<AdminTeleKpiRow[]> {
    return [];
}

export function getWeeklyRanges() {
    const now = new Date();
    const thisWeekStart = new Date(now);
    thisWeekStart.setDate(now.getDate() - now.getDay());
    thisWeekStart.setHours(0, 0, 0, 0);

    const thisWeekEnd = new Date(thisWeekStart);
    thisWeekEnd.setDate(thisWeekStart.getDate() + 6);
    thisWeekEnd.setHours(23, 59, 59, 999);

    const lastWeekStart = new Date(thisWeekStart);
    lastWeekStart.setDate(thisWeekStart.getDate() - 7);

    const lastWeekEnd = new Date(thisWeekStart);
    lastWeekEnd.setDate(thisWeekStart.getDate() - 1);
    lastWeekEnd.setHours(23, 59, 59, 999);

    return {
        thisWeek: { from: thisWeekStart, to: thisWeekEnd },
        lastWeek: { from: lastWeekStart, to: lastWeekEnd }
    };
}

// Additional missing exports for telesales earnings page
export const COMMISSION_RATE = 0.03; // 3%

export function calculateCombinedMetrics(tasks: any[], orders: any[], from: Date, to: Date) {
    return {
        totalCalls: 0,
        totalOrders: 0,
        totalRevenue: 0,
        totalCommission: 0,
        conversionRate: 0
    };
}

export function calculateKpiHistory(tasks: any[], from: Date, to: Date, orders: any[]): Array<{
    dateLabel: string;
    calls: number;
    orders: number;
    revenue: number;
    commission: number;
}> {
    // Stub implementation - returns empty array
    // In real implementation, would aggregate tasks/orders by date
    return [];
}

export function getTodayTargetForCurrentUser() {
    return {
        callsPerDay: 50,
        ordersPerDay: 5,
        revenuePerDay: 5000000
    };
}

export function calculateKpiRemaining(metrics: any, target: any) {
    return {
        calls: Math.max(0, target.callsPerDay - metrics.totalCalls),
        orders: Math.max(0, target.ordersPerDay - metrics.totalOrders),
        revenue: Math.max(0, target.revenuePerDay - metrics.totalRevenue),
        isCompleted: metrics.totalCalls >= target.callsPerDay &&
            metrics.totalOrders >= target.ordersPerDay &&
            metrics.totalRevenue >= target.revenuePerDay
    };
}
