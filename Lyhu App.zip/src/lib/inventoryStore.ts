import { createClient } from './supabaseClient';

const supabase = createClient();
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const getHeaders = (token?: string) => ({
    'Content-Type': 'application/json',
    'apikey': SUPABASE_KEY || '',
    'Authorization': `Bearer ${token || SUPABASE_KEY}`,
    'Prefer': 'return=representation' // Useful for RPCs sometimes
});

// Types matching DB schema
export interface InventoryLevel {
    id: string;
    warehouse_id: string;
    product_id: string;
    quantity_on_hand: number;
    quantity_committed: number;
    quantity_available: number;
    updated_at: string;
}

export interface InventoryTransaction {
    id: string;
    warehouse_id: string;
    product_id: string;
    type: 'inbound' | 'outbound' | 'reserve' | 'release' | 'adjustment';
    quantity: number;
    reference_type?: string;
    reference_id?: string;
    note?: string;
    performed_by?: string;
    created_at: string;
}

export interface RPCResponse {
    success: boolean;
    message?: string;
    available?: number;
}

// ==========================================================
// CORE FUNCTIONS (Calling RPCs)
// ==========================================================

/**
 * Reserve stock for an order (Giữ hàng)
 * Use when Order is CREATED or CONFIRMED
 */
export async function reserveStock(
    warehouseId: string,
    productId: string,
    quantity: number,
    orderId: string,
    userId: string,
    token?: string
): Promise<RPCResponse> {
    try {
        const headers = getHeaders(token);
        const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/fn_reserve_stock`, {
            method: 'POST',
            headers,
            body: JSON.stringify({
                p_warehouse_id: warehouseId,
                p_product_id: productId,
                p_quantity: quantity,
                p_ref_id: orderId,
                p_user_id: userId
            })
        });

        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.message || 'Error calling fn_reserve_stock');
        }

        const data = await res.json();
        return data as RPCResponse;
    } catch (err: any) {
        console.error('reserveStock error:', err);
        return { success: false, message: err.message || 'Lỗi giữ hàng' };
    }
}

/**
 * Release stock (Nhả hàng)
 * Use when Order is CANCELLED
 */
export async function releaseStock(
    warehouseId: string,
    productId: string,
    quantity: number,
    orderId: string,
    userId: string
): Promise<RPCResponse> {
    try {
        const { data, error } = await supabase.rpc('fn_release_stock', {
            p_warehouse_id: warehouseId,
            p_product_id: productId,
            p_quantity: quantity,
            p_ref_id: orderId,
            p_user_id: userId
        });

        if (error) throw error;
        return data as RPCResponse;
    } catch (err: any) {
        console.error('releaseStock error:', err);
        return { success: false, message: err.message || 'Lỗi nhả hàng' };
    }
}

/**
 * Ship stock (Xuất kho)
 * Use when Order is SHIPPED/COMPLETED
 */
export async function shipStock(
    warehouseId: string,
    productId: string,
    quantity: number,
    orderId: string,
    userId: string
): Promise<RPCResponse> {
    try {
        const { data, error } = await supabase.rpc('fn_ship_stock', {
            p_warehouse_id: warehouseId,
            p_product_id: productId,
            p_quantity: quantity,
            p_ref_id: orderId,
            p_user_id: userId
        });

        if (error) throw error;
        return data as RPCResponse;
    } catch (err: any) {
        console.error('shipStock error:', err);
        return { success: false, message: err.message || 'Lỗi xuất kho' };
    }
}

/**
 * Add stock (Nhập kho)
 * Use for Manual Inbound or Purchase Order
 */
export async function addStock(
    warehouseId: string,
    productId: string,
    quantity: number,
    userId: string,
    note: string = 'Nhập hàng thủ công'
): Promise<RPCResponse> {
    try {
        const { data, error } = await supabase.rpc('fn_add_stock', {
            p_warehouse_id: warehouseId,
            p_product_id: productId,
            p_quantity: quantity,
            p_user_id: userId,
            p_note: note
        });

        if (error) throw error;
        return data as RPCResponse;
    } catch (err: any) {
        console.error('addStock error:', err);
        return { success: false, message: err.message || 'Lỗi nhập kho' };
    }
}

// ==========================================================
// QUERY FUNCTIONS
// ==========================================================

export async function getInventoryLevel(productId: string, warehouseId?: string, token?: string): Promise<InventoryLevel | null> {
    try {
        const headers = getHeaders(token);

        // If warehouseId not provided, verify if we have a default one.
        let targetWarehouseId = warehouseId;

        if (!targetWarehouseId) {
            // Fetch default warehouse via API
            const whRes = await fetch(`${SUPABASE_URL}/rest/v1/warehouses?select=id&code=eq.MAIN-HN&limit=1`, { headers });
            if (whRes.ok) {
                const whData = await whRes.json();
                if (whData && whData.length > 0) targetWarehouseId = whData[0].id;
            }
        }

        if (!targetWarehouseId) return null;

        const res = await fetch(
            `${SUPABASE_URL}/rest/v1/inventory_levels?select=*&warehouse_id=eq.${targetWarehouseId}&product_id=eq.${productId}&limit=1`,
            { headers }
        );

        if (!res.ok) throw new Error('Failed to fetch inventory level');

        const data = await res.json();
        const level = data && data.length > 0 ? data[0] : null;

        return level as InventoryLevel;
    } catch (err) {
        console.error('getInventoryLevel error:', err);
        return null;
    }
}

export async function getDefaultWarehouseId(token?: string): Promise<string | null> {
    try {
        const headers = getHeaders(token);
        const res = await fetch(
            `${SUPABASE_URL}/rest/v1/warehouses?select=id&status=eq.active&order=created_at.asc&limit=1`,
            { headers }
        );

        if (!res.ok) return null;

        const data = await res.json();
        return data && data.length > 0 ? data[0].id : null;
    } catch { return null; }
}
export async function fetchAllInventoryLevels(warehouseId?: string): Promise<(InventoryLevel & { product: { name: string; sku: string; brand: string } })[]> {
    try {
        let targetWarehouseId = warehouseId;
        if (!targetWarehouseId) {
            targetWarehouseId = await getDefaultWarehouseId() || undefined;
        }

        if (!targetWarehouseId) return [];

        const { data, error } = await supabase
            .from('inventory_levels')
            .select(`
                *,
                product:products (
                    name,
                    sku,
                    brand
                )
            `)
            .eq('warehouse_id', targetWarehouseId)
            .order('product_id');

        if (error) {
            console.error('fetchAllInventoryLevels error:', error);
            return [];
        }

        return data as any;
    } catch (err) {
        console.error('fetchAllInventoryLevels exception:', err);
        return [];
    }
}
export async function fetchInventoryTransactions(warehouseId?: string, limit = 50): Promise<(InventoryTransaction & { product: { name: string; sku: string } })[]> {
    try {
        let targetWarehouseId = warehouseId;
        if (!targetWarehouseId) {
            targetWarehouseId = await getDefaultWarehouseId() || undefined;
        }

        if (!targetWarehouseId) return [];

        const { data, error } = await supabase
            .from('inventory_transactions')
            .select(`
                *,
                product:products (
                    name,
                    sku
                )
            `)
            .eq('warehouse_id', targetWarehouseId)
            .order('created_at', { ascending: false })
            .limit(limit);

        if (error) {
            console.error('fetchInventoryTransactions error:', error);
            return [];
        }

        return data as any;
    } catch (err) {
        console.error('fetchInventoryTransactions exception:', err);
        return [];
    }
}
export async function adjustStock(
    warehouseId: string,
    productId: string,
    newQuantity: number,
    userId: string,
    note: string
): Promise<{ success: boolean; message: string }> {
    try {
        const { data, error } = await supabase.rpc('fn_adjust_stock', {
            p_warehouse_id: warehouseId,
            p_product_id: productId,
            p_new_quantity: newQuantity,
            p_user_id: userId,
            p_note: note
        });

        if (error) {
            console.error('adjustStock error:', error);
            return { success: false, message: error.message };
        }

        return data as { success: boolean; message: string };
    } catch (err: any) {
        console.error('adjustStock exception:', err);
        return { success: false, message: err.message };
    }
}
