import { createClient } from "@/lib/supabaseClient";

export const supabase = createClient();
import { Product } from "@/mocks/data";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const getHeaders = (token?: string) => ({
    'Content-Type': 'application/json',
    'apikey': SUPABASE_KEY || '',
    'Authorization': `Bearer ${token || SUPABASE_KEY}`,
    'Prefer': 'return=representation'
});

export type OrderStatus = 'pending' | 'processing' | 'delivered' | 'cancelled' | 'draft';
export type OrderSource = 'TELESALES' | 'CUSTOMER' | 'SALES' | 'CTV' | 'SHOPEE' | 'TIKTOK' | 'WEB' | 'FACEBOOK' | 'ZALO';
export type FraudStatus = "NONE" | "FLAGGED" | "CONFIRMED" | "CLEARED";

export interface Order {
    id: string;
    readableId: number;
    customerName: string;
    totalAmount: number;
    status: OrderStatus;
    createdAt: string;
    source: OrderSource;
    telesalesUserId?: string;
    items?: any[];
    customerId?: string;
    leadId?: string;
    flagged?: boolean; // For fraud scan
    fraudStatus?: FraudStatus;

    // CTV / Extended Fields
    ctvId?: string;
    ctvCommission?: number;
    fulfillmentMode?: FulfillmentMode;
    receiverPhone?: string;
    receiverAddress?: string;
    notes?: string;
    ctvPaidAt?: string; // Timestamp when commission was paid
}

export type FulfillmentMode = 'SELF_SHIP' | 'LYHU_SHIP';

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
    pending: "Chờ xác nhận",
    processing: "Đang xử lý",
    delivered: "Đã giao",
    cancelled: "Đã hủy",
    draft: "Nháp"
};

export const FRAUD_STATUS_LABELS: Record<FraudStatus, string> = {
    NONE: "An toàn",
    FLAGGED: "Cảnh báo",
    CONFIRMED: "Gian lận",
    CLEARED: "Đã xác minh",
};

const STORAGE_KEY = "lyhu_all_orders";

// --- SYNC ---
export const loadOrders = (): Order[] => {
    if (typeof window === "undefined") return [];
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch {
        return [];
    }
};

export const saveOrders = (orders: Order[]) => {
    if (typeof window === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
    window.dispatchEvent(new Event("orders-updated"));
};

export const addOrder = (orderData: any): Order => {
    const orders = loadOrders();
    const newOrder: Order = {
        id: `ORD-${Date.now()}`,
        readableId: Date.now(),
        customerName: orderData.customerName || "Unknown",
        totalAmount: orderData.totalAmount || 0,
        status: orderData.status || 'pending',
        createdAt: new Date().toISOString(),
        source: orderData.source || 'CUSTOMER',
        ...orderData
    };
    saveOrders([newOrder, ...orders]);
    return newOrder;
};

// --- HELPERS (Restored for Admin) ---

export const updateOrderStatus = async (
    orderId: string,
    newStatus: OrderStatus,
    userId?: string  // Optional: for inventory actions
) => {
    // 1. Sync Update (localStorage) - for local UI
    const orders = loadOrders();
    const updated = orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
    saveOrders(updated);

    // 2. For Supabase orders (UUIDs), get old status first then update
    if (!orderId.startsWith("ORD-")) {
        // Fetch current status from DB before updating
        const { data: currentOrder, error: fetchError } = await supabase
            .from('orders')
            .select('status')
            .eq('id', orderId)
            .single();

        const oldStatus = currentOrder?.status;

        // Update status in DB
        const { error } = await supabase
            .from('orders')
            .update({ status: newStatus })
            .eq('id', orderId);

        if (error) {
            console.error("[updateOrderStatus] Supabase update failed:", error);
            return;
        }

        // 3. Inventory Actions based on status change
        if (userId && oldStatus && oldStatus !== newStatus) {
            if (newStatus === 'delivered' && oldStatus !== 'delivered') {
                await shipOrderInventory(orderId, userId);
            } else if (newStatus === 'cancelled' && oldStatus !== 'cancelled') {
                await releaseOrderInventory(orderId, userId);
            }
        } else if (!userId) {
            console.warn("[updateOrderStatus] No userId provided - skipping inventory actions");
        }
    }
};

// Helper: Ship all items in an order (when delivered)
async function shipOrderInventory(orderId: string, userId: string) {
    const warehouseId = await getDefaultWarehouseId();
    if (!warehouseId) {
        console.warn("[shipOrderInventory] No warehouse found");
        return;
    }

    // Fetch order items
    const { data: items, error } = await supabase
        .from('order_items')
        .select('product_id, quantity')
        .eq('order_id', orderId);

    if (error || !items) {
        console.error("[shipOrderInventory] Failed to fetch items:", error);
        return;
    }

    // Ship each item
    for (const item of items) {
        try {
            await shipStock(warehouseId, item.product_id, item.quantity, orderId, userId);
        } catch (err) {
            console.error("[shipOrderInventory] Failed to ship:", item.product_id, err);
        }
    }
}

// Helper: Release all items in an order (when cancelled)
async function releaseOrderInventory(orderId: string, userId: string) {
    const warehouseId = await getDefaultWarehouseId();
    if (!warehouseId) {
        console.warn("[releaseOrderInventory] No warehouse found");
        return;
    }

    // Fetch order items
    const { data: items, error } = await supabase
        .from('order_items')
        .select('product_id, quantity')
        .eq('order_id', orderId);

    if (error || !items) {
        console.error("[releaseOrderInventory] Failed to fetch items:", error);
        return;
    }

    // Release each item
    for (const item of items) {
        try {
            await releaseStock(warehouseId, item.product_id, item.quantity, orderId, userId);
        } catch (err) {
            console.error("[releaseOrderInventory] Failed to release:", item.product_id, err);
        }
    }
}

export const getOrdersSummary = () => {
    const orders = loadOrders();
    return {
        totalOrders: orders.length,
        totalPending: orders.filter(o => o.status === 'pending').length,
        totalProcessing: orders.filter(o => o.status === 'processing').length,
        totalDelivered: orders.filter(o => o.status === 'delivered').length,
        totalCancelled: orders.filter(o => o.status === 'cancelled').length,
        totalRevenue: orders.filter(o => o.status !== 'cancelled' && o.status !== 'draft')
            .reduce((sum, o) => sum + (o.totalAmount || 0), 0)
    };
};

export const filterOrdersByStatus = (orders: Order[], status: OrderStatus | 'all'): Order[] => {
    if (status === 'all') return orders;
    return orders.filter(o => o.status === status);
};

export const getOrdersByCustomer = (customerId: string): Order[] => {
    const orders = loadOrders();
    return orders.filter(o => o.customerId === customerId);
};

// --- ASYNC ---
// --- ASYNC (PURE FETCH) ---
export const fetchOrders = async (token?: string): Promise<Order[]> => {
    try {
        const headers = getHeaders(token);

        // REST: select=*,items:order_items(*,product:products(name,sku))
        const query = `select=*,items:order_items(*,product:products(name,sku))&order=created_at.desc`;

        const response = await fetch(
            `${SUPABASE_URL}/rest/v1/orders?${query}`,
            { headers }
        );

        if (!response.ok) {
            const errorText = await response.text();
            console.error("[fetchOrders] Error:", response.status, errorText);
            return [];
        }

        const data = await response.json();

        return (data || []).map((o: any) => ({
            id: o.id,
            readableId: o.readable_id,
            customerName: o.customer_name || "Khách hàng",
            totalAmount: o.total_amount,
            status: o.status as OrderStatus,
            createdAt: o.created_at,
            source: o.source || "TELESALES",
            telesalesUserId: o.telesales_user_id,
            items: o.items,
            customerId: o.customer_id,
            leadId: o.lead_id
        }));
    } catch (err) {
        console.error("[fetchOrders] Exception:", err);
        return [];
    }
};

import { getDefaultWarehouseId, reserveStock, shipStock, releaseStock } from "@/lib/inventoryStore";

export const addOrderSupabase = async (orderData: any, token?: string) => {
    const headers = getHeaders(token);
    const warehouseId = await getDefaultWarehouseId(token);

    // 1. Create Order
    // Insert: POST /rest/v1/orders
    try {
        const orderPayload = {
            lead_id: orderData.lead_id || orderData.leadId,
            customer_id: orderData.customer_id || orderData.customerId,
            customer_name: orderData.customerName || "Khách hàng",
            telesales_user_id: orderData.telesalesUserId,
            status: orderData.status || 'draft',
            total_amount: orderData.totalAmount,
            source: orderData.source || 'CUSTOMER'
        };

        const orderRes = await fetch(`${SUPABASE_URL}/rest/v1/orders`, {
            method: 'POST',
            headers,
            body: JSON.stringify(orderPayload)
        });

        if (!orderRes.ok) {
            const errBody = await orderRes.text();
            console.error("Error creating order:", errBody);
            return { success: false, error: errBody };
        }

        // Return=representation makes it return the created object
        // but default might be empty if not specified in header 'Prefer: return=representation'. 
        // getHeaders includes it.

        const orderResData = await orderRes.json();
        const order = Array.isArray(orderResData) ? orderResData[0] : orderResData;

        if (!order) {
            return { success: false, error: "Failed to parse created order" };
        }

        // 2. Create Order Items & Reserve Stock
        if (orderData.items && orderData.items.length > 0) {
            const itemsToInsert = orderData.items.map((item: any) => ({
                order_id: order.id,
                product_id: item.productId,
                quantity: item.quantity,
                price: item.unitPrice || item.price || 0
            }));

            const itemsRes = await fetch(`${SUPABASE_URL}/rest/v1/order_items`, {
                method: 'POST',
                headers,
                body: JSON.stringify(itemsToInsert)
            });

            if (!itemsRes.ok) {
                const errItems = await itemsRes.text();
                console.error("Error creating order items:", errItems);
                return { success: true, data: order, warning: "Order created but items failed: " + errItems };
            }

            // 3. Reserve Inventory (Async)
            if (warehouseId && orderData.telesalesUserId) {
                // We purposefully don't await this blocking UI if we want speed, but for safety lets await or catch.
                // Loop vs Batch? RPC is single?
                for (const item of orderData.items) {
                    try {
                        await reserveStock(
                            warehouseId,
                            item.productId,
                            item.quantity,
                            order.id,
                            orderData.telesalesUserId,
                            token
                        );
                    } catch (err) {
                        console.error("[addOrderSupabase] Reserve failed:", item.productId, err);
                    }
                }
            }
        }
        return { success: true, data: order };

    } catch (e: any) {
        console.error("addOrderSupabase Exception", e);
        return { success: false, error: e.message };
    }
};
