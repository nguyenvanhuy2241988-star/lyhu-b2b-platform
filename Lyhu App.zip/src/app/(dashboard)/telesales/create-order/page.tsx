"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Product } from "@/mocks/data";
import { fetchCustomers, Customer, fetchDealItems } from "@/lib/crmDealsStore";
import { loadProducts } from "@/lib/supabase/products";
import { ShoppingCart, Plus, Minus, Trash2, CheckCircle, User, ArrowLeft, Building } from "lucide-react";
import { addOrderSupabase } from "@/lib/ordersStore";
import { useAuth } from "@/components/auth/AuthProvider";
import { createClient } from "@/lib/supabaseClient";
import { reserveStock, getInventoryLevel, getDefaultWarehouseId } from "@/lib/inventoryStore";

const supabase = createClient();

const formatPrice = (price: number) => {
    return new Intl.NumberFormat("vi-VN", {
        style: "currency",
        currency: "VND",
    }).format(price);
};

interface OrderItem {
    product: Product;
    quantity: number;
}

function TelesalesCreateOrderContent() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const { user, session } = useAuth();

    // Get deal_id and customer_id from URL
    const dealIdFromUrl = searchParams.get('deal_id');
    const customerIdFromUrl = searchParams.get('customer_id');

    // Data State
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [inventory, setInventory] = useState<Record<string, number>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [currentWarehouseId, setCurrentWarehouseId] = useState<string | null>(null);
    const [dealInfo, setDealInfo] = useState<{ id: string; title: string } | null>(null);




    useEffect(() => {
        const fetchData = async () => {
            if (!user || !session?.access_token) return;

            setIsLoading(true);
            try {
                const [custs, prods, warehouseId] = await Promise.all([
                    fetchCustomers(undefined, session.access_token), // Fetch ALL customers
                    loadProducts(session.access_token),
                    getDefaultWarehouseId(session.access_token)
                ]);

                if (custs) setCustomers(custs);
                if (prods) setProducts(prods);
                if (warehouseId) setCurrentWarehouseId(warehouseId);

                // Fetch Real-time Inventory
                if (warehouseId) {
                    const invMap: Record<string, number> = {};
                    await Promise.all(prods.map(async (p) => {
                        const level = await getInventoryLevel(p.id, warehouseId, session.access_token);
                        invMap[p.id] = level?.quantity_available ?? 0;
                    }));
                    setInventory(invMap);
                }

                // Auto-select customer if coming from CRM
                if (customerIdFromUrl && custs) {
                    const customer = custs.find(c => c.id === customerIdFromUrl);
                    if (customer) {
                        setSelectedCustomer(customer);
                        setCurrentStep(2);
                    }
                }

                if (dealIdFromUrl) {
                    // TODO: Refactor fetchDeal to Pure Fetch in crmDealsStore. 
                    // For now, if we use supabase client here it effectively might deadlock if Realtime is active elsewhere.
                    // But we used createClient defined in file.
                    // Ideally: const deal = await fetchDeal(dealIdFromUrl, session.access_token);
                    // But fetchDeal isn't updated to take token yet. 

                    // fetchDealItems IS updated to take token.
                    const items = await fetchDealItems(dealIdFromUrl, session.access_token);
                    if (items.length > 0) {
                        const mappedItems: OrderItem[] = [];
                        items.forEach(di => {
                            const prod = prods.find(p => p.id === di.product_id);
                            if (prod) {
                                mappedItems.push({
                                    product: prod,
                                    quantity: di.quantity
                                });
                            }
                        });
                        if (mappedItems.length > 0) {
                            setOrderItems(mappedItems);
                        }
                    }

                    // Fetch deal title manually with fetch to be safe?
                    // const { data } = await supabase.from('crm_deals').select('id, title').eq('id', dealIdFromUrl).single();
                    // if (data) setDealInfo(data);
                }
            } catch (err) {
                console.error("Error loading create-order data:", err);
            } finally {
                setIsLoading(false);
            }
        };

        if (session?.access_token) {
            fetchData();
        }
    }, [customerIdFromUrl, dealIdFromUrl, user, session?.access_token]);

    // Step 1: Select customer
    const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

    // Step 2 & 3: Add products and quantities
    const [orderItems, setOrderItems] = useState<OrderItem[]>([]);

    // UI state
    const [currentStep, setCurrentStep] = useState(1);

    const handleSelectCustomer = (customerId: string) => {
        const customer = customers.find((c) => c.id === customerId);
        setSelectedCustomer(customer || null);
        if (customer) {
            setCurrentStep(2);
        }
    };

    const handleAddProduct = (product: Product) => {
        const existingItem = orderItems.find((item) => item.product.id === product.id);

        if (existingItem) {
            const available = inventory[product.id] ?? 0;
            if (existingItem.quantity + 1 > available) {
                alert(`Chỉ còn ${available} sản phẩm trong kho!`);
                return;
            }
            setOrderItems((prev) =>
                prev.map((item) =>
                    item.product.id === product.id
                        ? { ...item, quantity: item.quantity + 1 }
                        : item
                )
            );
        } else {
            setOrderItems((prev) => [...prev, { product, quantity: 1 }]);
        }
    };

    const handleUpdateQuantity = (productId: string, delta: number) => {
        setOrderItems((prev) =>
            prev.map((item) => {
                if (item.product.id === productId) {
                    const newQuantity = Math.max(1, item.quantity + delta);
                    const available = inventory[productId] ?? 0;

                    if (newQuantity > available) {
                        alert(`Kho chỉ còn ${available} sản phẩm!`);
                        return item;
                    }

                    return { ...item, quantity: newQuantity };
                }
                return item;
            })
        );
    };

    const handleRemoveItem = (productId: string) => {
        setOrderItems((prev) => prev.filter((item) => item.product.id !== productId));
    };

    const calculateTotal = () => {
        return orderItems.reduce((sum, item) => {
            return sum + (item.product.wholesalePrice || 0) * item.quantity;
        }, 0);
    };

    const handleCreateOrder = async () => {
        if (!selectedCustomer) return;

        const userId = user?.id;
        if (!userId) {
            alert("❌ Không xác định được người dùng. Vui lòng đăng nhập lại.");
            return;
        }

        const total = calculateTotal();

        // 1. Create Order in Shared Store
        const res = await addOrderSupabase({
            customerId: selectedCustomer.id,
            customerName: selectedCustomer.name,
            source: "TELESALES",
            telesalesUserId: userId,
            items: orderItems.map((item) => ({
                sku: item.product.sku || "N/A",
                name: item.product.name,
                brand: item.product.brand || "LHU",
                quantity: item.quantity,
                unit: item.product.unit || "Cái",
                unitPrice: item.product.wholesalePrice,
                subtotal: (item.product.wholesalePrice || 0) * item.quantity,
                productId: item.product.id
            })),
            totalAmount: total,
            status: "draft",
            notes: dealInfo ? `Đơn hàng từ cơ hội: ${dealInfo.title}` : "Đơn hàng tạo bởi Telesales"
        }, session?.access_token);

        if (res?.success && res.data) {
            const newOrder = res.data;
            console.log("Created telesales order:", newOrder);

            // 2. Success message
            alert("✅ Tạo đơn hàng thành công & Đã giữ hàng!");

            // 3. Reset and Redirect
            setSelectedCustomer(null);
            setOrderItems([]);
            setCurrentStep(1);
            router.push("/telesales/orders");
        } else {
            console.error(res?.error);
            alert(`❌ Tạo đơn hàng thất bại: ${res?.error || "Lỗi không xác định"}`);
        }
    };

    const handleReset = () => {
        setSelectedCustomer(null);
        setOrderItems([]);
        setCurrentStep(1);
    };

    if (isLoading) {
        return <div className="p-6">Đang tải dữ liệu...</div>;
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Tạo đơn hàng mới</h1>
                <p className="text-sm text-slate-600 mt-1">
                    Tạo đơn hàng cho khách hàng trong danh sách của bạn
                </p>
            </div>

            {/* Progress Steps */}
            <div className="bg-white p-6 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${currentStep >= 1
                                ? "bg-indigo-600 text-white"
                                : "bg-slate-100 text-slate-400"
                                }`}
                        >
                            {currentStep > 1 ? <CheckCircle className="w-5 h-5" /> : "1"}
                        </div>
                        <div>
                            <p className="font-medium text-slate-900">Chọn khách hàng</p>
                            <p className="text-xs text-slate-500">Khách cần đặt hàng</p>
                        </div>
                    </div>

                    <div className="hidden sm:block w-12 h-0.5 bg-slate-200"></div>

                    <div className="flex items-center gap-3">
                        <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${currentStep >= 2
                                ? "bg-indigo-600 text-white"
                                : "bg-slate-100 text-slate-400"
                                }`}
                        >
                            {currentStep > 2 ? <CheckCircle className="w-5 h-5" /> : "2"}
                        </div>
                        <div>
                            <p className="font-medium text-slate-900">Chọn sản phẩm</p>
                            <p className="text-xs text-slate-500">Thêm vào đơn</p>
                        </div>
                    </div>

                    <div className="hidden sm:block w-12 h-0.5 bg-slate-200"></div>

                    <div className="flex items-center gap-3">
                        <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${currentStep >= 3 && orderItems.length > 0
                                ? "bg-indigo-600 text-white"
                                : "bg-slate-100 text-slate-400"
                                }`}
                        >
                            3
                        </div>
                        <div>
                            <p className="font-medium text-slate-900">Xác nhận</p>
                            <p className="text-xs text-slate-500">Tạo đơn hàng</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Step 1: Select Customer */}
            {currentStep === 1 && (
                <div className="bg-white p-6 rounded-xl border border-slate-200">
                    <h3 className="font-semibold text-slate-900 mb-4">Chọn khách hàng</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {customers.map((customer) => (
                            <button
                                key={customer.id}
                                onClick={() => handleSelectCustomer(customer.id)}
                                className="p-4 border border-slate-200 rounded-lg hover:border-indigo-500 hover:bg-indigo-50 transition-all text-left group"
                            >
                                <div className="flex items-start gap-3">
                                    <div className="p-2 bg-slate-100 group-hover:bg-indigo-100 rounded-lg transition-colors">
                                        <User className="w-5 h-5 text-slate-600 group-hover:text-indigo-600" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h4 className="font-medium text-slate-900 mb-1 truncate">
                                            {customer.name}
                                        </h4>
                                        <p className="text-xs text-slate-500">
                                            {customer.address}
                                        </p>
                                    </div>
                                </div>
                            </button>
                        ))}
                        {customers.length === 0 && (
                            <p className="text-slate-500 col-span-3 text-center py-4">Chưa có khách hàng nào.</p>
                        )}
                    </div>
                </div>
            )}

            {/* Step 2: Select Products */}
            {currentStep >= 2 && selectedCustomer && (
                <>
                    {/* Selected Customer Info */}
                    <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-lg flex items-center justify-between">
                        <div>
                            <p className="text-sm text-indigo-700 font-medium">Khách hàng đã chọn:</p>
                            <p className="text-lg font-semibold text-indigo-900">
                                {selectedCustomer.name}
                            </p>
                            <p className="text-xs text-indigo-600 mt-1">
                                {selectedCustomer.address}
                            </p>
                        </div>
                        <button
                            onClick={handleReset}
                            className="px-4 py-2 bg-white text-indigo-700 border border-indigo-300 rounded-lg text-sm font-medium hover:bg-indigo-100 transition-colors"
                        >
                            Đổi khách
                        </button>
                    </div>

                    {/* Product Selection */}
                    <div className="bg-white p-6 rounded-xl border border-slate-200">
                        <h3 className="font-semibold text-slate-900 mb-4">Chọn sản phẩm</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                            {products.map((product) => {
                                const inOrder = orderItems.find((item) => item.product.id === product.id);
                                const brandColors: Record<string, string> = {
                                    UHI: "bg-orange-500",
                                    BOYO: "bg-purple-500",
                                    CVT: "bg-blue-500",
                                    LYHU: "bg-indigo-500",
                                };
                                const brandColor = brandColors[product.brand || "LHU"] || "bg-indigo-500";

                                return (
                                    <div
                                        key={product.id}
                                        className={`p-4 border rounded-lg ${inOrder ? "border-indigo-500 bg-indigo-50" : "border-slate-200"
                                            }`}
                                    >
                                        <span className={`inline-block ${brandColor} text-white text-xs font-semibold px-2 py-1 rounded mb-2`}>
                                            {product.brand || "LHU"}
                                        </span>
                                        <h4 className="font-medium text-slate-900 text-sm mb-2 line-clamp-2 min-h-[2.5rem]">
                                            {product.name}
                                        </h4>
                                        <p className="text-xs text-slate-500 mb-2">SKU: {product.sku}</p>
                                        <p className="text-lg font-bold text-slate-900 mb-1">
                                            {formatPrice(product.wholesalePrice || 0)}
                                        </p>
                                        <p className={`text-xs font-semibold mb-3 ${(inventory[product.id] ?? 0) > 0 ? 'text-green-600' : 'text-red-600'
                                            }`}>
                                            {(inventory[product.id] ?? 0) > 0
                                                ? `Sẵn hàng: ${inventory[product.id]}`
                                                : 'Hết hàng'}
                                        </p>
                                        <button
                                            onClick={() => handleAddProduct(product)}
                                            disabled={(inventory[product.id] ?? 0) <= 0}
                                            className={`w-full py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors ${(inventory[product.id] ?? 0) <= 0
                                                ? "bg-slate-100 text-slate-400 cursor-not-allowed" // Disabled style
                                                : inOrder
                                                    ? "bg-indigo-600 text-white hover:bg-indigo-700"
                                                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                                                }`}
                                        >
                                            <Plus className="w-4 h-4" />
                                            {inOrder ? `Đã thêm (${inOrder.quantity})` : "Thêm vào đơn"}
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* Order Summary */}
                    {orderItems.length > 0 && (
                        <div className="bg-white p-6 rounded-xl border border-slate-200">
                            <h3 className="font-semibold text-slate-900 mb-4">Đơn hàng ({orderItems.length} sản phẩm)</h3>

                            <div className="space-y-3 mb-6">
                                {orderItems.map((item) => (
                                    <div
                                        key={item.product.id}
                                        className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg"
                                    >
                                        <div className="flex-1 min-w-0">
                                            <h4 className="font-medium text-slate-900 text-sm">{item.product.name}</h4>
                                            <p className="text-xs text-slate-500 mt-1">
                                                {formatPrice(item.product.wholesalePrice || 0)} × {item.quantity}
                                            </p>
                                        </div>

                                        <div className="flex items-center gap-2">
                                            <button
                                                onClick={() => handleUpdateQuantity(item.product.id, -1)}
                                                disabled={item.quantity <= 1}
                                                className="p-1.5 hover:bg-white rounded transition-colors disabled:opacity-50"
                                            >
                                                <Minus className="w-4 h-4" />
                                            </button>
                                            <span className="w-8 text-center font-semibold">{item.quantity}</span>
                                            <button
                                                onClick={() => handleUpdateQuantity(item.product.id, 1)}
                                                className="p-1.5 hover:bg-white rounded transition-colors"
                                            >
                                                <Plus className="w-4 h-4" />
                                            </button>
                                        </div>

                                        <div className="text-right">
                                            <p className="font-semibold text-slate-900">
                                                {formatPrice((item.product.wholesalePrice || 0) * item.quantity)}
                                            </p>
                                        </div>

                                        <button
                                            onClick={() => handleRemoveItem(item.product.id)}
                                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                            </div>

                            <div className="border-t border-slate-200 pt-4">
                                <div className="flex items-center justify-between mb-4">
                                    <span className="text-lg font-semibold text-slate-900">Tổng cộng:</span>
                                    <span className="text-2xl font-bold text-indigo-600">
                                        {formatPrice(calculateTotal())}
                                    </span>
                                </div>

                                <div className="flex gap-3">
                                    <button
                                        onClick={handleReset}
                                        className="flex-1 px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold transition-colors"
                                    >
                                        Hủy
                                    </button>
                                    <button
                                        onClick={handleCreateOrder}
                                        className="flex-1 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
                                    >
                                        <ShoppingCart className="w-5 h-5" />
                                        Tạo đơn
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

export default function TelesalesCreateOrderPage() {
    return (
        <Suspense fallback={
            <div className="p-6 flex items-center justify-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full"></div>
            </div>
        }>
            <TelesalesCreateOrderContent />
        </Suspense>
    );
}
