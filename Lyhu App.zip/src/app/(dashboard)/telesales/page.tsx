"use client";

import { useEffect, useState } from "react";
import { Users, Phone, ShoppingBag, TrendingUp, ArrowRight, Loader2 } from "lucide-react";
import Link from "next/link";
import { getMyTasks, TelesalesTask } from "@/lib/telesalesTasksStore";
import { fetchSalesLeads, SalesLead } from "@/lib/salesLeads";
import { fetchOrders, Order } from "@/lib/ordersStore";
import { useAuth } from "@/components/auth/AuthProvider";

const formatPrice = (price: number) => {
    return new Intl.NumberFormat("vi-VN", {
        style: "currency",
        currency: "VND",
    }).format(price);
};

const formatDate = (dateString: string) => {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString("vi-VN");
    } catch {
        return dateString;
    }
};

export default function TelesalesDashboard() {
    const { user, session } = useAuth();

    // State for data
    const [tasks, setTasks] = useState<TelesalesTask[]>([]);
    const [leads, setLeads] = useState<SalesLead[]>([]);
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    // SAFE ACCESS: Ensure arrays
    const safeTasks = Array.isArray(tasks) ? tasks : [];
    const safeLeads = Array.isArray(leads) ? leads : [];
    const safeOrders = Array.isArray(orders) ? orders : [];

    // Load all data
    useEffect(() => {
        let alive = true;

        const loadAll = async () => {
            setIsLoading(true);
            try {
                // Load tasks
                const taskRows = await getMyTasks(user?.id, session?.access_token);
                if (!alive) return;
                setTasks(Array.isArray(taskRows) ? taskRows : []);

                // Load leads from Supabase
                const leadRows = await fetchSalesLeads(user?.id, session?.access_token);
                if (!alive) return;
                setLeads(Array.isArray(leadRows) ? leadRows : []);

                // Load orders from Supabase (all orders, will filter by source if needed)
                const orderRows = await fetchOrders(session?.access_token);
                if (!alive) return;
                setOrders(Array.isArray(orderRows) ? orderRows : []);

            } catch (e) {
                console.error("Error loading dashboard data", e);
                if (!alive) return;
                setTasks([]);
                setLeads([]);
                setOrders([]);
            } finally {
                if (alive) setIsLoading(false);
            }
        };

        loadAll();
        return () => { alive = false; };
    }, [user?.id, session?.access_token]);

    // --- KPI CALCULATIONS ---

    // 1. Leads to Call - count leads with status 'new' or 'contacted'
    const leadsToCallCount = safeLeads.filter(l =>
        l.status === 'NEW' || l.status === 'CONTACTED'
    ).length;

    // 2. Closed Today (Đã chốt hôm nay) - orders delivered today
    const today = new Date();
    const closedTodayCount = safeOrders.filter(o => {
        if (o.status !== 'delivered') return false;
        const dateStr = o.createdAt;
        if (!dateStr) return false;
        const date = new Date(dateStr);
        return (
            date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear()
        );
    }).length;

    // 3. Monthly Revenue (Doanh số tháng) - sum of delivered orders this month
    const monthlyRevenue = safeOrders
        .filter(o => {
            if (o.status !== 'delivered') return false;
            const dateStr = o.createdAt;
            if (!dateStr) return false;
            const date = new Date(dateStr);
            return (
                date.getMonth() === today.getMonth() &&
                date.getFullYear() === today.getFullYear()
            );
        })
        .reduce((sum, o) => sum + (o.totalAmount || 0), 0);

    // 4. Total Orders this month
    const monthlyOrdersCount = safeOrders.filter(o => {
        const dateStr = o.createdAt;
        if (!dateStr) return false;
        const date = new Date(dateStr);
        return (
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear()
        );
    }).length;

    const statsCards = [
        {
            label: "Lead cần gọi",
            value: leadsToCallCount.toString(),
            change: "Mới + Đã liên hệ",
            icon: Phone,
            color: "text-blue-600",
            bg: "bg-blue-50",
        },
        {
            label: "Đã giao hôm nay",
            value: closedTodayCount.toString() + " đơn",
            change: "Hoàn thành",
            icon: ShoppingBag,
            color: "text-green-600",
            bg: "bg-green-50",
        },
        {
            label: "Doanh số tháng",
            value: formatPrice(monthlyRevenue),
            change: "Từ đơn đã giao",
            icon: TrendingUp,
            color: "text-purple-600",
            bg: "bg-purple-50",
        },
        {
            label: "Đơn hàng tháng",
            value: monthlyOrdersCount.toString(),
            change: "Đơn đã tạo",
            icon: Users,
            color: "text-orange-600",
            bg: "bg-orange-50",
        },
    ];

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                {statsCards.map((stat, index) => {
                    const Icon = stat.icon;
                    return (
                        <div
                            key={index}
                            className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow"
                        >
                            <div className="flex items-center justify-between mb-4">
                                <div className={`p-3 rounded-lg ${stat.bg}`}>
                                    <Icon className={`w-6 h-6 ${stat.color}`} />
                                </div>
                            </div>
                            <div>
                                <p className="text-sm text-slate-600 font-medium mb-1">{stat.label}</p>
                                <h3 className="text-2xl font-bold text-slate-900">{stat.value}</h3>
                            </div>
                            <div className="mt-4 flex items-center text-sm border-t border-slate-100 pt-3">
                                <span className="text-slate-500">{stat.change}</span>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Performance Section */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="flex flex-col md:flex-row gap-8">
                    {/* Stats */}
                    <div className="flex-1 space-y-6">
                        <div>
                            <h3 className="text-lg font-semibold text-slate-900 mb-1">Thống kê nhanh</h3>
                            <p className="text-sm text-slate-500">Tình hình hoạt động</p>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                                <p className="text-xs text-slate-500 uppercase font-medium mb-1">Tổng Lead</p>
                                <div className="flex items-end gap-2">
                                    <span className="text-2xl font-bold text-slate-900">
                                        {safeLeads.length}
                                    </span>
                                    <span className="text-xs text-green-600 font-medium mb-1">lead</span>
                                </div>
                            </div>
                            <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                                <p className="text-xs text-slate-500 uppercase font-medium mb-1">Tổng Đơn</p>
                                <div className="flex items-end gap-2">
                                    <span className="text-2xl font-bold text-slate-900">
                                        {safeOrders.length}
                                    </span>
                                    <span className="text-xs text-slate-500 mb-1">đơn hàng</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Order Status Chart */}
                    <div className="flex-1 flex flex-col justify-end h-[200px]">
                        <div className="flex items-end justify-between h-full gap-2 pt-6">
                            {(() => {
                                const statuses = ['pending', 'processing', 'delivered', 'cancelled'];
                                const labels = ['Chờ', 'Xử lý', 'Giao', 'Hủy'];
                                const colors = ['bg-yellow-500', 'bg-blue-500', 'bg-green-500', 'bg-red-400'];
                                const counts = statuses.map(s => safeOrders.filter(o => o.status === s).length);
                                const max = Math.max(...counts, 1);

                                return counts.map((count, i) => (
                                    <div key={i} className="flex flex-col items-center gap-2 flex-1 group cursor-pointer">
                                        <div className="relative w-full bg-slate-100 rounded-t-md overflow-hidden flex items-end h-[150px]">
                                            <div
                                                className={`w-full ${colors[i]} hover:opacity-80 transition-all rounded-t-md relative`}
                                                style={{ height: `${(count / max) * 100}%`, minHeight: count > 0 ? '20px' : '0' }}
                                            >
                                                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded pointer-events-none transition-opacity">
                                                    {count}
                                                </div>
                                            </div>
                                        </div>
                                        <span className="text-xs font-medium text-slate-500">{labels[i]}</span>
                                    </div>
                                ));
                            })()}
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Priority Leads Table - Now from Supabase */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
                    <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                        <h3 className="text-lg font-semibold text-slate-900">Lead ưu tiên</h3>
                        <Link href="/telesales/leads-queue" className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center gap-1">
                            Xem tất cả <ArrowRight className="w-4 h-4" />
                        </Link>
                    </div>
                    <div className="overflow-x-auto flex-1">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                                <tr>
                                    <th className="px-6 py-3 font-medium">Khách hàng</th>
                                    <th className="px-6 py-3 font-medium">Trạng thái</th>
                                    <th className="px-6 py-3 font-medium text-right">Nguồn</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {safeLeads.slice(0, 5).map((lead) => (
                                    <tr key={lead.id} className="hover:bg-slate-50">
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-slate-900">{lead.storeName || lead.contactName || 'N/A'}</div>
                                            <div className="text-xs text-slate-500">{lead.phone || 'Chưa có SĐT'}</div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${lead.status === 'NEW' ? 'bg-blue-100 text-blue-800' :
                                                lead.status === 'CONTACTED' ? 'bg-yellow-100 text-yellow-800' :
                                                    lead.status === 'WON' ? 'bg-green-100 text-green-800' :
                                                        'bg-slate-100 text-slate-800'
                                                }`}>
                                                {lead.status === 'NEW' ? 'Mới' :
                                                    lead.status === 'CONTACTED' ? 'Đã liên hệ' :
                                                        lead.status === 'WON' ? 'Đã chốt' : lead.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-right text-slate-500 text-xs">
                                            {lead.source || '-'}
                                        </td>
                                    </tr>
                                ))}
                                {safeLeads.length === 0 && (
                                    <tr>
                                        <td colSpan={3} className="px-6 py-8 text-center text-slate-500">
                                            Chưa có lead nào
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Recent Orders Table - Now from Supabase */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
                    <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                        <h3 className="text-lg font-semibold text-slate-900">Đơn mới nhất</h3>
                        <Link href="/telesales/orders" className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center gap-1">
                            Xem tất cả <ArrowRight className="w-4 h-4" />
                        </Link>
                    </div>
                    <div className="overflow-x-auto flex-1">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                                <tr>
                                    <th className="px-6 py-3 font-medium">Mã đơn</th>
                                    <th className="px-6 py-3 font-medium">Khách hàng</th>
                                    <th className="px-6 py-3 font-medium text-right">Tổng tiền</th>
                                    <th className="px-6 py-3 font-medium text-right">Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {safeOrders.slice(0, 5).map((order) => (
                                    <tr key={order.id} className="hover:bg-slate-50">
                                        <td className="px-6 py-4 font-medium text-slate-900">
                                            {order.readableId ? `ORD-${order.readableId}` : order.id.slice(0, 8)}
                                            <div className="text-xs text-slate-500">{formatDate(order.createdAt)}</div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-slate-900 truncate max-w-[120px]" title={order.customerName}>
                                                {order.customerName || 'Khách hàng'}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-right font-medium text-slate-900">
                                            {formatPrice(order.totalAmount || 0)}
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                                order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                                                    order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                                                        'bg-red-100 text-red-800'
                                                }`}>
                                                {order.status === 'pending' ? 'Chờ xác nhận' :
                                                    order.status === 'processing' ? 'Đang xử lý' :
                                                        order.status === 'delivered' ? 'Đã giao' : 'Đã hủy'}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                                {safeOrders.length === 0 && (
                                    <tr>
                                        <td colSpan={4} className="px-6 py-8 text-center text-slate-500">
                                            Chưa có đơn hàng nào
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
