'use client';

import { useEffect, useState } from 'react';
import { Package, AlertTriangle, ArrowRight, Archive } from "lucide-react";
import Link from 'next/link';
import { createClient } from '@/lib/supabaseClient';

export default function WarehouseDashboard() {
    const [stats, setStats] = useState({
        totalProducts: 0,
        lowStock: 0,
        outOfStock: 0
    });

    useEffect(() => {
        const fetchStats = async () => {
            const supabase = createClient();

            // Get default warehouse
            const { data: wh } = await supabase.from('warehouses').select('id').eq('code', 'MAIN-HN').single();
            const warehouseId = wh?.id;

            if (warehouseId) {
                const { data: levels } = await supabase
                    .from('inventory_levels')
                    .select('quantity_on_hand')
                    .eq('warehouse_id', warehouseId);

                if (levels) {
                    const total = levels.length; // Approximate total products tracked
                    const low = levels.filter(l => l.quantity_on_hand > 0 && l.quantity_on_hand < 10).length;
                    const out = levels.filter(l => l.quantity_on_hand <= 0).length;
                    setStats({ totalProducts: total, lowStock: low, outOfStock: out });
                }
            }
        };
        fetchStats();
    }, []);

    return (
        <div className="p-6 max-w-7xl mx-auto space-y-6">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-slate-800">Kho vận & Hàng hóa</h1>
                <p className="text-slate-500 mt-2">Quản lý nhập xuất và tồn kho</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Total Products */}
                <Link href="/warehouse/inventory" className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition group">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-50 text-blue-600 rounded-xl group-hover:scale-110 transition-transform">
                            <Package className="w-8 h-8" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-slate-500">Tổng sản phẩm</p>
                            <h3 className="text-2xl font-bold text-slate-800">{stats.totalProducts}</h3>
                        </div>
                    </div>
                </Link>

                {/* Low Stock */}
                <Link href="/warehouse/inventory?filter=low" className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition group">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-amber-50 text-amber-600 rounded-xl group-hover:scale-110 transition-transform">
                            <AlertTriangle className="w-8 h-8" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-slate-500">Sắp hết hàng (&lt;10)</p>
                            <h3 className="text-2xl font-bold text-slate-800">{stats.lowStock}</h3>
                        </div>
                    </div>
                </Link>

                {/* Out of Stock */}
                <Link href="/warehouse/inventory?filter=out" className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition group">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:scale-110 transition-transform">
                            <Archive className="w-8 h-8" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-slate-500">Đã hết hàng</p>
                            <h3 className="text-2xl font-bold text-slate-800">{stats.outOfStock}</h3>
                        </div>
                    </div>
                </Link>
            </div>

            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h3 className="font-bold text-lg mb-4 text-slate-800">Truy cập nhanh</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Link href="/warehouse/inventory" className="flex items-center justify-between p-4 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 transition">
                        <span className="font-medium flex items-center gap-2"><ArrowRight className="w-4 h-4" /> Xem Tất Cả Tồn Kho</span>
                        <Archive className="w-4 h-4" />
                    </Link>
                    <Link href="/warehouse/import" className="flex items-center justify-between p-4 rounded-xl bg-slate-50 hover:bg-green-50 hover:text-green-700 transition">
                        <span className="font-medium flex items-center gap-2"><Archive className="w-4 h-4" /> Nhập Kho Mới</span>
                        <ArrowRight className="w-4 h-4" />
                    </Link>
                    <Link href="/warehouse/export" className="flex items-center justify-between p-4 rounded-xl bg-slate-50 hover:bg-red-50 hover:text-red-700 transition">
                        <span className="font-medium flex items-center gap-2"><Package className="w-4 h-4" /> Xuất Kho (Thủ công)</span>
                        <ArrowRight className="w-4 h-4" />
                    </Link>
                </div>
            </div>
        </div>
    );
}
